document.addEventListener("DOMContentLoaded", function() {
    // Auto-dismiss Flash Messages after 4 seconds
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            let bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 4000);
});
