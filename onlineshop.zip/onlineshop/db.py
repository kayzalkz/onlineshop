import sqlalchemy
from app import app, db, User, Company, bcrypt

MYSQL_URI = 'mysql+pymysql://root:japu@localhost/'
DB_NAME = 'pos_system'

def reset_and_build_database():
    print(f"[*] Connecting to MySQL to reset/create database '{DB_NAME}'...")
    engine = sqlalchemy.create_engine(MYSQL_URI)
    
    with engine.connect() as conn:
        conn.execute(sqlalchemy.text(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}"))
        
    with app.app_context():
        # Drop everything to ensure the new columns (color, size, category) are created cleanly
        print("[*] Dropping old tables to prevent schema mismatch...")
        db.drop_all()
        
        print("[*] Building new tables...")
        db.create_all()

        if not Company.query.first():
            db.session.add(Company(name="KZL Boutique", address="Mandalay", phone="09123456789"))

        if not User.query.filter_by(username='root').first():
            hashed_pw = bcrypt.generate_password_hash('japu').decode('utf-8')
            db.session.add(User(username='root', password_hash=hashed_pw, role='admin'))

        db.session.commit()
        print("[+] Database setup completely finished! You can now run app.py.")

if __name__ == "__main__":
    reset_and_build_database()
